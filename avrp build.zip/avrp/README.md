## Feature
    - Client
        - Enregistrement (Client)
    - Admin
        - Generer Une Clef
        - Voire les Clef
        - Voire les Enregistrement
        - Imprimer Une Carte de l'enregistrement

## Model
    - User
    - Card
