export function Mcisme() {
    return (
        <div className="footer-bottom">
            <div className="container">
                <div className="row align-items-center">
                    
                    <div className="col-lg-12 col-md-12 text-center">
                        <p className="mb-0">© {new Date().getFullYear()} <a href="https://viraza.net" target="_blank">Viraza</a>. Designd By <a href="https://mcisme.viraza.net/" target="_blank">{['M','c','i','s','m','e'].join('')}</a> All Rights Reserved</p>
                    </div>
                    
                </div>
            </div>
        </div>
    )
}